#!/bin/sh

# Eventualy update the PATH
#PATH=/path/to/add:$PATH

BASEWORKDIR=`pwd`
echo $BASEWORKDIR

cp  $BASEWORKDIR/input/eCall.sct $BASEWORKDIR/hyvar/sensorE/src/model/eCall.sct
cd $BASEWORKDIR/hyvar
#run the headless code generation using yakindu
/home/yakindu-sctpro/scc -d sensorE
